# NM Design Lab — Android app project

This Android Studio project packages the current ad-free NM Design Lab photo editor in an Android WebView. It includes the website locally, an app name/theme, image picker support, and internet access for the optional AI image generation feature.

## Build the app

1. Install the current stable Android Studio.
2. Open this `NMDesignLabAndroid` folder in Android Studio.
3. Allow Gradle to sync and install any requested Android SDK Platform 35 / build tools.
4. Test on a real Android device or emulator using **Run**.
5. For Play Store delivery, choose **Build → Generate Signed Bundle / APK → Android App Bundle** and create a release signing key. Keep the key and passwords private and backed up.

## Before publishing

- Replace the temporary vector icon with a polished 512×512 Play Store icon and prepare phone screenshots.
- Publish the website/privacy policy at a stable HTTPS URL and update Play Console disclosures to match actual data handling.
- Test photo import, edits, AI generation, exports, rotation, and small screens on real devices.
- The optional AI Lab sends the prompt to an external image-generation provider. It requires internet and provider availability. The app does not include advertising SDKs or ad placements.
- Some WebView versions do not support downloading generated `blob:` URLs reliably. Verify image export on your target devices and fix this before production release.
- Google Play policy and account verification/testing requirements apply. This project is source code, not a signed APK/AAB and is not yet submitted to Google Play.

## Package identity

Application ID: `com.nmdesignlab.app`

Choose the final application ID before first publication; changing it later creates a different Play Store app.
